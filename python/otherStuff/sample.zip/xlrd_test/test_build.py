#!/usr/bin/env python
# -----------------------------------------------------------------
#    * NOTICE *           * NOTICE *             * NOTICE *
# -----------------------------------------------------------------
#  Copyright 2007 and beyond, neoPsy Systems, ALL RIGHTS RESERVED
#  ENFORCABLE UNDER COPYRIGHT LAW OF THE UNITED STATES OF AMERICA. 
#  Use, duplication, or disclosure of this software in part or in 
#  full is prohibited without the written concent of neoPsy Systems
#  or Somerville Partners LLC.
# -----------------------------------------------------------------
# 
"""
test_build.py
  Designed to extract the times from a formatted spreadsheet and generate
  a simple html page to show the fast time

Usage
  test_build.py [options]

Options
  -h, --help - print usage information
  -i, --input - excel spreadsheet with PA information (required)
  -o, --output - [directory] and file name of text output file (required)
"""

# imports
#
import xlrd as xl
import sys, os, getopt, operator
from exceptions import *

# ----------------------------------------------------------------
# usage
#
def usage():
    """
    prints documentation of this module - no parameters
    """
    print __doc__



# ----------------------------------------------------------------
# check/get/set command line options
#
def getCommandLine():
    try:
        opts, args = getopt.getopt(sys.argv[1:], "i:o:hvq",
                                   ["input=",
                                    "output=", "help",
                                    "verbose", "qa"])
    except getopt.GetoptError:
        print "\nInvalid argument"
        usage()
        sys.exit(2)

    requiredCount = 0

    verbose = False
    qaprint = False
    infile = "unknown"
    outfile = ''

    if len(opts) == 0:
        print "\nNo arguments passed"
        usage()
        sys.exit(2)
    
    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
            sys.exit()
        if o in ("-i", "--input"):
            infile = a
            requiredCount = requiredCount + 1
        if o in ("-o", "--output"):
            outfile = a

    if requiredCount < 1:
        print "\nOne or more required arguments missing"
        usage()
        sys.exit(2)

    return infile, outfile

# ----------------------------------------------------------------
# validate the workbook
#
def open_workbook(wbfile):

    try:                            
        theBook = xl.open_workbook(wbfile)
    except xl.XLRDError:
        print "*** Open failed: %s: %s" % sys.exc_info()[:2]
        sys.exit(2)
    except:
        print "*** Open failed: %s: %s" % sys.exc_info()[:2]
        sys.exit(2)  
    
    return theBook
    
# ----------------------------------------------------------------
# extract success profile information
#
def extract_open(theBook):
    """
    Extract open information
    Call with: workbook object
    Return: list
    """
    rv = []

    theSheet = theBook.sheet_by_name("Open")

    draw_num = theSheet.col(0)      # draw number is in column A
    fname = theSheet.col(1)         # first name in B
    lname = theSheet.col(2)         # last name in C
    horse = theSheet.col(3)         # horse in D
    run_time = theSheet.col(4)      # run time in column E
    penalty = theSheet.col(5)       # penalty in column F
    total_time = theSheet.col(6)    # total time column G
    #
    # now loop through the sheet extracting info from each column
    #
    for c in range(theSheet.nrows-1):
        # if run_time empty skip the row
        if (run_time[c+1].ctype == xl.XL_CELL_EMPTY):
            continue 
        drw = int(draw_num[c+1].value)
        fn = str(fname[c+1].value).strip().replace(' ','-')
        ln = str(lname[c+1].value)
        hs = str(horse[c+1].value)
        tm  = str(run_time[c+1].value)
        pn = str(penalty[c+1].value)
        tot  = float(total_time[c+1].value)
        rv.append([drw,fn,ln,hs,tm,pn,tot])

    return rv

# ----------------------------------------------------------------
# print out a division
# 
def print_d(name,dlist):
    """
    Print the first three items in the passed list
    """
    count = 0
    print '\n'
    print '-'*20,' ',name,' ','-'*20
    print '%-20s %-25s %-15s' % ('Draw','Name','Time')
    for x in dlist:
        count += 1
        print '%-20s %-25s %-15s' % (x[0],x[1]+' '+x[2],x[6])
        if count > 2: break


# ----------------------------------------------------------------
# build XML document
#
def build_html(outfile,oplist):
    """
    Builds an HTML document
    Call with:
    Returns: nothing
    """
    d1list = []
    d2list = []
    d3list = []
    d4list = []
    slist = sorted(oplist,key=operator.itemgetter(6))
    
    # find the fast time and determine where each D starts
    fast = slist[0][6]
    d2 = fast + 0.5
    d3 = d2 + 0.5
    d4 = d3 + 0.5

    # go through runners and move them to the appropriate D
    for x in slist:
        if x[6] >= d4: d4list.append(x)
        elif x[6] >= d3: d3list.append(x)
        elif x[6] >= d2: d2list.append(x)
        else: d1list.append(x)

    print_d('1D',d1list)
    print_d('2D',d2list)
    print_d('3D',d3list)
    print_d('4D',d4list)


# ----------------------------------------------------------------
# main program module
#
def main():

    # get all the stuff from the command line
    #
    infile,outfile = getCommandLine()

    theBook = open_workbook(infile)
    openlist = extract_open(theBook)
    
    if not outfile:
        outfile = 'fast_times.html'

    build_html(outfile,openlist)


# ----------------------------------------------------------------
#  run main
#
if __name__ == "__main__":
    main()
