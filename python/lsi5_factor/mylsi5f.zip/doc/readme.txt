DOI Scoring Service

For functional requirements information please see the functional requirements
document.

This service uses XML-RPC as its communication methodology on the following:

  Protocol: TCP/IP
  Port: 31031

To install:


To start: (by hand)


To configure automatic startup:


