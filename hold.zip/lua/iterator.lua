#!/usr/bin/env lua
--

a = {"one","two","three","four"}
for i,v in ipairs(a) do
  print(i,v)
end
